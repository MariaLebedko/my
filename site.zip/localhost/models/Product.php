<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "product".
 *
 * @property int $id
 * @property string $title
 * @property int $price
 * @property string $country
 * @property string $photo
 * @property string $model
 * @property int $year
 * @property int $count
 * @property int $id_category
 *
 * @property Category $category
 * @property OrderList[] $orderLists
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'product';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['title', 'price', 'country', 'photo', 'model', 'year', 'count', 'id_category'], 'required'],
            [['price', 'year', 'count', 'id_category'], 'integer'],
            [['title', 'country', 'photo', 'model'], 'string', 'max' => 255],
            [['id_category'], 'exist', 'skipOnError' => true, 'targetClass' => Category::className(), 'targetAttribute' => ['id_category' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'price' => 'Price',
            'country' => 'Country',
            'photo' => 'Photo',
            'model' => 'Model',
            'year' => 'Year',
            'count' => 'Count',
            'id_category' => 'Id Category',
        ];
    }

    /**
     * Gets query for [[Category]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCategory()
    {
        return $this->hasOne(Category::className(), ['id' => 'id_category']);
    }

    /**
     * Gets query for [[OrderLists]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOrderLists()
    {
        return $this->hasMany(OrderList::className(), ['id_product' => 'id']);
    }

    public static function otbor()
    {
        return $query=(new \yii\db\Query())
    ->select(['photo', 'title'])
    ->from('product')
    ->orderBy(['id' => SORT_DESC])
    ->limit(5)
    ->all();
    
    }
}
