<?php

use yii\bootstrap4\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm as WidgetsActiveForm;
use yii\widgets\ListView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\Search */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Каталог';
$this->params['breadcrumbs'][] = $this->title;

$this-> registerCssFile('@web/css/catalog.css');
?>
<div class="product-index" id="pjax-div">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php Pjax::begin(['enablePushState' => false, 'timeout' => 5000, 'id' => 'pjax-catalog']); ?>
     <?php echo $this->render('_search', ['model' => $searchModel, 'dataProvider' => $dataProvider,
            'catOtbor' => $catOtbor]); ?> 

    <?= ListView::widget([
        'dataProvider' => $dataProvider,
        'layout' => '{pager}<div class="row carta">{items}</div>{pager}',
        'pager' => ['class' => \yii\bootstrap4\LinkPager::class],
        'itemOptions' => ['class' => 'item'],
        'itemView' => function ($model, $key, $index, $widget) {
            $cartochka = '<div class="card " style="width: 18rem; height: 100%;">'
            . Html::a(Html::img("@web/img/{$model -> photo}", ['alt' => 'карточка', 'class' => 'card-img']), ['/catalog/view', 'id' => $model -> id]) 
            . '<div class="card-body">'
            .  Html::a('<h5 class="card-title"> '. $model -> title . '</h5>',['/catalog/view', 'id' => $model -> id])
            . '<p class="card-text"> '. $model -> price . '</p>'
            . '<a href="#" class="btn btn-primary">Подробнее</a>'
            . '<a href="#" class="btn btn-korzina">В корзину</a>'
           . '</div>'
         . '</div>';
            return $cartochka; //Html::a(Html::encode($model->title), ['view', 'id' => $model->id]);
        },
    ]) ?>

    <?php Pjax::end(); ?>

</div>
