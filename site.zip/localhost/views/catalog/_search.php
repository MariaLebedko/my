<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Search */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="product-search">

<div class="row">
    <div class="col-md-6">
        <div>Сортировка по:</div>
        <div class="row sort">
            <div class="sort-item first-item"><?= $dataProvider->sort->link('title', ['class' => 'btn btn-primary ser']) ?></div>
            <div class="sort-item"><?= $dataProvider->sort->link('price', ['class' => 'btn btn-primary ser']) ?></div>
            <div class="sort-item last-item"><?= $dataProvider->sort->link('year', ['class' => 'btn btn-primary ser']) ?></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="product-search">
            <?php $form = ActiveForm::begin([
                'action' => ['index'],
                'method' => 'get',
                'options' => [
                    'data-pjax' => 1
                ],
            ]); ?>
            <?php $params = [
                'prompt' => 'Все категории'
            ];
            echo $form->field($model, 'id_category')->dropdownList($catOtbor, $params)->label('Выберете категорию');
            ?>
        <div class="form-group">
            <?= Html::a('Сбросить всё', ['/catalog'], ['class' => 'btn btn-outline-secondary']) ?>
            <?= Html::submitButton('Найти',['class' => 'btn btn-primary']) ?>
           
        </div>
        <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
<!-- <div class="row">
    <div class="col">
            <?= Html::a('Сбросить всё', ['/catalog'], ['class' => 'btn btn-outline-secondary mt-3']) ?>
    </div>

</div> -->

</div>
